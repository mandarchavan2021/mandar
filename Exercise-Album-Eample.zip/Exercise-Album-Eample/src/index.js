import { Component } from "react";
import ReactDom from "react-dom";
import HeaderComp from "./components/header.component";
import MainComp from "./components/main.component";
import FooterComp from "./components/footer.component";

class MainApp extends Component{
    
    render(){
        console.log("MainApp's render was called");
        return <div>
                <HeaderComp/>
                <MainComp/>
                <FooterComp/>
            </div>
    }
}

ReactDom.render(<MainApp/>, document.getElementById("root"));